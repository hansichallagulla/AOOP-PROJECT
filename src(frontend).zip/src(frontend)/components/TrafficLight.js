import React from "react";
import "./TrafficLight.css";

const TrafficLight = ({ direction, signal }) => {
  return (
    <div className="traffic-light">
      <div className={`light red ${signal === "red" ? "active" : ""}`}></div>
      <div className={`light orange ${signal === "orange" ? "active" : ""}`}></div>
      <div className={`light green ${signal === "green" ? "active" : ""}`}></div>
      <p>{direction.toUpperCase()}</p>
    </div>
  );
};

export default TrafficLight;


