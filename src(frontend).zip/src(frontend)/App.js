import React, { useState, useEffect } from "react";
import TrafficLight from "./components/TrafficLight";
import "./App.css";

const App = () => {
  const [signal, setSignal] = useState("north");
  const [densities, setDensities] = useState({ north: 1, south: 1, east: 1, west: 1 });
  const [lightStates, setLightStates] = useState({
    north: "red",
    south: "red",
    east: "red",
    west: "red",
  });

  useEffect(() => {
    const updateSignal = () => {
      const maxDensityDirection = Object.keys(densities).reduce((a, b) =>
        densities[a] > densities[b] ? a : b
      );

      if (signal !== maxDensityDirection) {
        setLightStates((prevState) => ({
          ...prevState,
          [signal]: "orange",
        }));

        setTimeout(() => {
          setLightStates((prevState) => ({
            ...prevState,
            [signal]: "red",
          }));

          setTimeout(() => {
            setLightStates((prevState) => ({
              ...prevState,
              [maxDensityDirection]: "green",
            }));
            setSignal(maxDensityDirection);
          }, 500);
        }, 2000);
      }
    };

    updateSignal();
    const interval = setInterval(updateSignal, 5000);

    return () => clearInterval(interval);
  }, [densities, signal]);

  return (
    <div className="app">
      <h1>Smart Traffic Light System</h1>

      <div className="controls">
        <h2>Enter Vehicle Densities</h2>
        <div className="density-inputs">
          {Object.keys(densities).map((dir) => (
            <div key={dir} className="density-row">
              <label>{dir.toUpperCase()}:</label>
              <input
                type="number"
                min="1"
                value={densities[dir]}
                onChange={(e) =>
                  setDensities({ ...densities, [dir]: parseInt(e.target.value) || 1 })
                }
              />
            </div>
          ))}
        </div>
      </div>

      <div className="traffic-light-container">
        {["north", "south", "east", "west"].map((dir) => (
          <TrafficLight key={dir} direction={dir} signal={lightStates[dir]} />
        ))}
      </div>
    </div>
  );
};

export default App;